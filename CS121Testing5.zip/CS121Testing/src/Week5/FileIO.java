package Week5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileIO {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("courses.txt");


        //try {
            //Scanner console = new Scanner(file);
            //while (console.hasNextLine()) {
                //String Line = console.nextLine();
                //System.out.println(Line);
                //String course = console.nextLine();
                //int credits = Integer.parseInt(console.nextLine());
                //int score = Integer.parseInt(console.nextLine());
                //System.out.printf("%-7s %3d %7d \n", course, credits, score);

            }
        }//catch(FileNotFoundException e){
            //e.printStackTrace();

       