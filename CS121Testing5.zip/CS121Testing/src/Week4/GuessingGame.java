package Week4;


import java.util.Scanner;

public class GuessingGame {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        System.out.println("Guess a number 1-100 or q to quit");

        int num = 43;

        int i = Integer.parseInt(console.nextLine());
        while(num != i){

            if (num  < i)
            {
                System.out.println("lower!");
                break;
            }
            else if (num > i)
            {
                System.out.println("higher!");
                break;
            }
        }System.out.println("Congratulations.");
    }
    }
