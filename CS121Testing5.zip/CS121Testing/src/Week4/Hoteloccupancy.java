package Week4;

import javax.swing.*;

public class Hoteloccupancy {
    public static void main(String[] args) {
        int totalroom = 0;
        int totaloccu = 0;
        int floor = Integer.parseInt(JOptionPane.showInputDialog("How many floors does the hotel have?"));
        for (int i = 1; i <= floor; i++) {
            int room = Integer.parseInt(JOptionPane.showInputDialog("How many rooms does this floor have?"));
            int occupied = Integer.parseInt(JOptionPane.showInputDialog("How many occupied rooms on this floor have?"));
           totalroom += room;
           totaloccu += occupied;

        }
        int vacantrooms= totalroom-totaloccu;
        double ratio= (double) totaloccu /totalroom;
        System.out.println("You have " + floor + " floors");
        System.out.println("You have " +totalroom+ " rooms in your hotel");
        System.out.println("You have "+ totaloccu+ " occupied rooms in your hotel");
        System.out.println("You have " + vacantrooms+ " vacant rooms in your hotel");
        System.out.printf("Your occupancy rate is %.2f%n",ratio);
   }
}