package Week3;

import javax.swing.*;

public class Switch {
    public static void main(String[] args) {
        String planet = JOptionPane.showInputDialog(null, "enter a planet");
        String planetInfo = "";
        switch (planet) {
            case "earth":
                planetInfo = "Earth is the planet we live on it is 3rd from the sun. it has a diameter of 12,742 km.";
                break;
            case "mercury":
                planetInfo = "you entered mercury it is the 1st planet. It has a diameter of 4,780 km.";
                break;
            case "venus":
                planetInfo = "You entered in venus. it is the 2nd planet from the sun. it has a  diameter of 12,103.6 km.";
                break;
            case "Mars":
                planetInfo = "You entered in mars. It is the 4th planet from the sun. It has a has a diameter of 6,794 km";
                break;
            case "Saturn":
                planetInfo = "You entered in Saturn. it is the 6th planet from the sun. it has a  diameter of 58,232 km.";
                break;
            case "Jupiter":
                planetInfo = "You entered in mars. It is the 5th planet from the sun. It has a has a diameter of 1.39 million km";
                break;
            case "Neptune":
                planetInfo = "You entered in Neptune. it is the 8th planet from the sun. it has a  diameter of 49,500 km.";
                break;
            case "Uranus":
                planetInfo = "You entered in Uranus. It is the 7th planet from the sun. It has a has a diameter of 51,118 km";
                break;
                default:
                    planetInfo = "The planet you entered is not in the archive.";

        }
        JOptionPane.showMessageDialog(null, planetInfo);
    }
}
