package Week3;

import javax.swing.*;

public class Triangle {
    public static void main(String[] args) {
        int side1 = Integer.parseInt(JOptionPane.showInputDialog("Enter the first side"));
        int side2 = Integer.parseInt(JOptionPane.showInputDialog("Enter the Second side"));
        int side3 = Integer.parseInt(JOptionPane.showInputDialog("Enter the Third side"));

        {
            if (side1 == side2 && side1 == side3) {
                System.out.println("The triangle is Equilateral.");

            } else {
                if (side1 == side2 && side1 != side3 || side1 != side2 && side2 == side3 || side1 == side3 && side1 != side2) {
                    System.out.println("The triangle is Isosceles.");

                } else {
                    if (side1 != side2 && side1 != side3) {
                        System.out.println("The triangle is Scalene.");


                    }
                }
            }
        }}}