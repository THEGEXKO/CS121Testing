package Week4;

import java.util.Random;

public class RNDnumber {
    public static void main(String[] args) {
        double value = Math.random();
        Random rand = new Random();
        int ran = rand.nextInt(10);
        double rande = rand.nextInt(10);
        double values = rand.nextDouble() * 10;
    }
}
