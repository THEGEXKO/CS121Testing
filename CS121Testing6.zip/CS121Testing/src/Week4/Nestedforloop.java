package Week4;

public class Nestedforloop {
    public static void main(String[] args) {
        for (int i = 0; i < 4; i++) {
            System.out.println("this is i :" +i + "\n");
            for (int j = 0; j < 5; j++) {
                System.out.println("------- this is j ;"+j );
            }
            System.out.println();
        }
        int[][] matrix ={
                {11,22,33},
                {45,54,65},
                {78,87,97}
        };
    for(int i =0; i <matrix.length; i++){
        System.out.println("this is i"+i + "\n");
        for(int j = 0; j<matrix[i].length;j++){
            System.out.println(matrix[i][j] + " ");
        }
    }
    int  n = 7;
    for(int i =0; i < n;i++){
        for(int j =0; j <i ;j++){
            System.out.println("* ");
        }
        System.out.println();

    }
    }

}