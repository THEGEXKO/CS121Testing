package Week5;

import java.util.Scanner;

public class AverageRainfall {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        System.out.println("How many years was recorded?");
        int year = Integer.parseInt(console.nextLine());
        int totalrain = 0;
        int totalmonth= 0;
        for (int i = 1; i <= year; i++) {
            for (int j = 1; j <= 12; j++) {

                System.out.println("\n What was the rain fall in inches for month? "+j);
                int rain = Integer.parseInt(console.nextLine());


                totalrain += rain;
                totalmonth = i*12;
            }

        }
        double ave = (double) totalrain/totalmonth;
        System.out.println("The average rain fall was "+ ave);
        System.out.println("The amount of months recorded: "+totalmonth);
        System.out.println("The total amount of rainfall: "+ totalrain);

    }

}

