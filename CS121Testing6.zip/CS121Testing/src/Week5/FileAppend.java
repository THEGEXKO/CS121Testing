package Week5;

import javax.swing.*;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileAppend {
    public static void main(String[] args) throws IOException {

    try {

        FileWriter filewrite = new FileWriter("Text.txt", true);
        PrintWriter output = new PrintWriter(filewrite);
        String Name = JOptionPane.showInputDialog("Enter name:");
        int num = Integer.parseInt(JOptionPane.showInputDialog("Enter Number"));
        String Phrase =JOptionPane.showInputDialog("Enter Phrase");
        output.printf("%n%-20s %-20s %6s", Name,num,Phrase);
        filewrite.close();
        output.close();
    } catch (FileNotFoundException e) {
    }
}

}
