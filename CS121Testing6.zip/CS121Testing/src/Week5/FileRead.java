package Week5;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class FileRead {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("Text.txt");

        try {
            Scanner console = new Scanner(file);
            while (console.hasNextLine()) {
                String Line = console.nextLine();
                System.out.println(Line);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
