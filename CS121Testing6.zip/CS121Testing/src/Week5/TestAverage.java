package Week5;

import javax.swing.*;

public class TestAverage {
    public static void main(String[] args) {
        int totalscore=0;
        int student = Integer.parseInt(JOptionPane.showInputDialog("How many students do you have?"));
        //double ave = 0;
        for (int i = 1; i <= student; i++) {
            int test = Integer.parseInt(JOptionPane.showInputDialog("How many tests did the student have?"));
            System.out.println("\n Student "+ i +" Stats");
            totalscore=0;

            for (int j = 1; j <= test; j++) {
                int score = Integer.parseInt(JOptionPane.showInputDialog("What was the score on this test?"));
                System.out.println("Test score for test"+ j +" is: " + score);

                totalscore += score;

            }
            double ave = (double) totalscore/test;
            System.out.println("The average of their tests were "+ ave);
        }

    }
}