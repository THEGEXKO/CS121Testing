package Week5;


import java.util.Scanner;

public class MethodActivity {

    public static double getLength(double Length) {
        Scanner console = new Scanner(System.in);
        return Integer.parseInt(console.nextLine());
    }
    public static double getWidth(double Width) {
        Scanner console = new Scanner(System.in);
        return Integer.parseInt(console.nextLine());
    }
    public static double getArea(double Width , double Length) {
         double Area = (Width * Length);
         return Area;
    }
    public static String Display(double Area, double Width, double Length) {
        String Data = String.format("%-20s, %-20s, %-20s", Area, Width,Length);
        return Data;
    }
}


