package Week5;
import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class FileWrite {
    public static void main(String[] args) throws FileNotFoundException {
        File outputFile = new File("Text.txt");
        PrintWriter output = new PrintWriter(outputFile);
        output.printf("%-20s ", "<User Name> <num> <Phrase>");
        String Name, Phrase;
        int num;
        Name = JOptionPane.showInputDialog("Enter name:");
        num = Integer.parseInt(JOptionPane.showInputDialog("Enter Number: "));
        Phrase = JOptionPane.showInputDialog("Enter Phrase: ");
        output.printf("%n%-20s %-20s %6s", Name, num, Phrase);

        output.close();
    }
}

