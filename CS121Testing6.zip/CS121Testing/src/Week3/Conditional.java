package Week3;

import java.util.EventListener;

public class Conditional {
    public static void main(String[] args) {

        //(condition){


        //if (condition) {


        //else{


        //else if(condition){




        int age = 21;
        double gpa = 3.9;


        boolean csmajor,isStudent,isTeacher;
        csmajor=false;
        isStudent=true;
        isTeacher=true;
        String name = "Eli";
        String name2 = "William";
        if(age<=21) {
            System.out.println("your age is less than equal to 21. \n");
        }else{
            System.out.println("Your are older than 21");
        }
        if (gpa >= 4.0) {
            System.out.println("you recieve a A");
        } else if (gpa>=3.6) {
            System.out.println("You recieve a A-");
        } else if (gpa >=2.6) {
            System.out.println();
        }

         if(csmajor == isStudent) {
            System.out.println("you are a student and a cs major");
         if (!name.equals(name2)) {
            System.out.printf("Name one %s is not equal to %s%n", name, name2);
         //if (Teacher == TeachMajorCS);
            }}

        }
}