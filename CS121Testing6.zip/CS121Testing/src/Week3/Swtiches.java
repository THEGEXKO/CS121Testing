package Week3;

import javax.swing.*;

public class Swtiches {
    public static void main(String[] args) {
        String planet = JOptionPane.showInputDialog(null, "enter a planet");
        String planetInfo = "";
        switch (planet) {
            case "earth":
                planetInfo = "Earth is the planet we live on.";
                break;
            case "mercury":
                planetInfo = "you entered mercury";
                break;
            case "venus":
                planetInfo = "You entered in venus";
            default:
                planetInfo = "The planet you entered is not in the archive.";
                break;


        }
        JOptionPane.showMessageDialog(null, planetInfo);


        String planetExpress = JOptionPane.showInputDialog(null, "enter a planet");
        String planetInfoExpress = switch(planetExpress) {
            case "earth" -> "earth is the planet we live on";
            case "mercury" -> "you entered mercury";
            case "venus" -> "you entered venus";
            default -> "Sorry, the planet you entered does not have info";
        };
        JOptionPane.showMessageDialog(null,planetInfoExpress);
    }
}
