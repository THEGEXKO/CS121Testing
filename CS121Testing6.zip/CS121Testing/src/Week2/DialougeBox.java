package Week2;

import javax.swing.*;

public class DialougeBox {
    public static void main(String[] args) {
        String fname = JOptionPane.showInputDialog("Enter your first name");
        String lname = JOptionPane.showInputDialog("Enter your last name");
        System.out.println(fname.toUpperCase());
        System.out.println(lname.toUpperCase());
        System.out.println(fname.toLowerCase());
        System.out.println(lname.toLowerCase());
        StringBuilder freversedName = new StringBuilder(fname);
        StringBuilder lreversedName = new StringBuilder(lname);
        System.out.println(freversedName.reverse());
        System.out.println(lreversedName.reverse());

        int numOne = Integer.parseInt(JOptionPane.showInputDialog("Enter your first number"));
        int numTwo = Integer.parseInt(JOptionPane.showInputDialog("Enter your second number"));
        int add = (numOne + numTwo);
        int sub = (numOne - numTwo);
        int mult = (numOne * numTwo);
        int div = (numOne / numTwo);
        double sqrt1 = Math.sqrt(numOne);
        int power1 = (int) Math.pow(numOne,numTwo);
        double log1 = Math.log(numOne);

        System.out.printf("The number %d + %d =%d%n",numOne,numTwo,add);
        System.out.printf("The number %d - %d =%d%n",numOne,numTwo,sub);
        System.out.printf("The number %d * %d =%d%n",numOne,numTwo,mult);
        System.out.printf("The number %d / %d =%d%n",numOne,numTwo,div);
        System.out.printf("The square root of %d is = %.2f%n",numOne,sqrt1);
        System.out.printf("The power of %d of %d is :%d%n", numOne, numTwo, power1);
        System.out.printf("The log of %d is %.2f%n", numOne,log1);
    }
}
