package Week6;

public class car {
        //Member Variables/ Instance Variables/fields
        String Make, Model, Color, VIN;
        int year;
        boolean isElectric;
        car (String make, String model, String color, String vin, int year){
            this.Make = make;
            this.Model = model;
            this.Color = color;
            this.VIN =vin;
            this.year = year;
        }
        //Method
        //Setters and GETTERS
        public void setMake (String make){

        }
        //public void
        public void DisplayInfo () {
        }
    }