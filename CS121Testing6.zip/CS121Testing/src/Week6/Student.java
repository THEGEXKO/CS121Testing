package Week6;

public class Student {
    String name;
    String grade;
    double GPA;
    boolean isStudent;


    Student(String name, double GPA){
        this.name = name;
        this.GPA = GPA;

    }

    public void setName(String name,double GPA){
        this.name = name;
        this.GPA = GPA;

    }
    public void Displayinfo(){
        System.out.printf("The Name of the student is %s%nThe GPA is %.4f%n",name,GPA);
    }
    }
