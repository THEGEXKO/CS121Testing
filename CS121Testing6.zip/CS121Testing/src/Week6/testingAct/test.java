package Week6.testingAct;

public class test {
    public boolean checkContents;
    private String name;
    private Integer Num;
    private String content ="";

    public test(String name,Integer Num){
        this.name=name;
        this.Num= Num;
    }
    public String getName(){
        return name;
    }
    public Integer getNum(){
        return Num;
    }
    public boolean CheckContents(){
        if(this.content.isEmpty()){
            return false;
        }else{
            return true;
        }
    }

    public String getContent() {
        return content;
    }
}
