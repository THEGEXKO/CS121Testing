package Week6.EncapulationActivity;

public class TestEncap {
    public static void main(String[] args) {
        Encap1 Encap = new Encap1("Jimothy", 432, 3.9,"Hello");
        System.out.println(Encap.getName());
        //System.out.println(Encap.getNumber());
        System.out.println(Encap.getGPA());
        System.out.println(Encap.getPassword());





    }
}
