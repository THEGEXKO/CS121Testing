package Week6.EncapulationActivity;

public class Encap1 {
    public String Name;
    public Integer Number;
    private double GPA;
    private String Password;


    public Encap1(String Name, Integer Number, double GPA, String Password ){
        this.Name = Name;
        this.Number = Number;
        this.GPA = GPA;
        this.Password =Password;
    }

    public String getName(){
        return Name;
    }

    private Integer getNumber(){
        return Number;
    }
    protected double getGPA(){
        return GPA;
    }
    String getPassword(){
        return Password;
    }
}
