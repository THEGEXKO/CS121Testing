package Week6;


public class Test {
    public static void main(String[] args) {
        //Scanner console = new Scanner(System.in);
        car Tesla = new car("Tesla","S","Red","123FHEJNEUF",2002);
        System.out.println(Tesla.year);

        Student student1 = new Student("Louis",3.9);
        student1.Displayinfo();

    }
}
