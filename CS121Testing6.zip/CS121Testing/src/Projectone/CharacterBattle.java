package Projectone;


public class CharacterBattle {
    String name;
    int HP;
    String move;
    int movePower;
    int attackSpeed;

    CharacterBattle(String name, int HP, String move, int movePower, int attackSpeed) {
        this.name = name;
        this.HP = HP;
        this.move = move;
        this.movePower = movePower;
        this.attackSpeed = attackSpeed;
    }


        public void setName(String Name){
            this.name= Name;
        }
        public void setHP(int HP){
            this.HP = HP;
        }
        public void setMove(String move){
            this.move = move;
        }
        public void setmovePower(int movePower){
            this.movePower = movePower;
        }
        public void setAttackSpeed(int attackSpeed){
            this.attackSpeed = attackSpeed;
        }
        public String getName(){
            return this.name;

        }
        public int getHP(){
            return this.HP;
        }
        public String move(){
            return this.move;
        }
        public int getAttackPower(){
            return this.movePower;
        }
        public int getAttackSpeed(){
            return this.attackSpeed;
        }
    }




