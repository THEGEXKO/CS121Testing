package Projectone;

import java.util.Scanner;

public class CharacterTest {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);


        System.out.println("Enter Character name:");
        String name =console.nextLine();
        System.out.println("Enter Character HP");
        int HP = Integer.parseInt(console.nextLine());
        System.out.println("Enter Characters attack move name");
        String move = console.nextLine();
        System.out.println("Enter moves attack power");
        int movePower = Integer.parseInt(console.nextLine());
        System.out.println("Enter moves speed");
        int movespeed = Integer.parseInt(console.nextLine());
        CharacterBattle Rocco = new CharacterBattle(name,HP,move,movePower,movespeed);
        CharacterBattle Papier = new CharacterBattle(name,HP,move,movePower,movespeed);
        CharacterBattle Scisic = new CharacterBattle(name,HP,move,movePower,movespeed);
    }
/*

         */
    }