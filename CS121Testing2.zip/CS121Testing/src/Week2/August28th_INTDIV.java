package Week2;

import java.security.spec.RSAOtherPrimeInfo;
import java.sql.SQLOutput;
import java.util.Locale;
import java.util.Scanner;

public class August28th_INTDIV{
     public static void main(String[] args) {
         Scanner console = new Scanner(System.in);

         String color = "Blue";
         //color.concat("red");
         //System.out.println(color);

         String name = "Helen";

         System.out.println(name.charAt(3));
         System.out.println(name.length());

         System.out.println(name.substring(0));
         System.out.println(" ");
         System.out.println(name.substring(0,1));
         //uppercase
         System.out.println(name.toUpperCase());
         //lowercase
         System.out.println(name.toLowerCase());
         //.replace()
         System.out.println(name.replace("Helen", "Jacob"));

         /*System.out.println("Enter you name");
         String name = console.nextLine();
         System.out.println(name);

         System.out.println("enter in age");
         //int age = console.nextInt();
         int age = Integer.parseInt(console.nextLine());
         System.out.println(age);

         System.out.println("Enter in gpa");
         //double gpa = console.nextDouble();
         //double gpa = Double.parseDouble(console);
         //System.out.println(gpa);

         //Shortcut print
         int numOne = 1;
         int numTwo = 4;
         int numThree = 5;
         int numFour = 99;
         int numFive = 50;
         int result1 = numOne/numTwo;

         double result2 = (double)(numOne)/numTwo;
         double result3 = (double)(numFour)/numTwo;
         double result4 = (double)(numThree)/numTwo;
         double result5 = (double)(numFive)/numFour;

         //System.out.println(result1);
         //System.out.println(result2);
         //System.out.println(result3);
         //System.out.println(result4);
         //System.out.println(result5);
         console.close();

          */
     }

}
