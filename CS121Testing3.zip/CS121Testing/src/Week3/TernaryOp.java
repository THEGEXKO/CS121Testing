package Week3;

public class TernaryOp {
    public static void main(String[] args) {
        boolean isSunny, isWarm;
        isSunny = true;
        isWarm = false;


        if(isSunny && isWarm) {
            System.out.println("Lets go for ice cream");
        }else{
            System.out.println("Lets not get ice cream");
        }
        if (isSunny || isWarm){
            System.out.println("Its either sunny or warm. Lets go for a walk.");
        }

        int num = 8;
        String results = (num % 2 == 0)? "Even" : "Odd";
        System.out.println("The number is "+ results);

    }
}
