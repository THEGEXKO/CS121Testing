package Week2;

import javax.swing.*;

public class DialougeBOXaug29 {
    public static void main(String[] args) {

        String name = JOptionPane.showInputDialog("Enter your name");
        JOptionPane.showMessageDialog(null,name);

        int age = Integer.parseInt(JOptionPane.showInputDialog("Enter your age"));
        JOptionPane.showMessageDialog(null,age);

        double gpa = Double.parseDouble(JOptionPane.showInputDialog("Enter your gpa"));
        JOptionPane.showMessageDialog(null,gpa);
    }
}
