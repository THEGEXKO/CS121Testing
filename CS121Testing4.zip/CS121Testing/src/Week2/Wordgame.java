package Week2;

import java.util.Scanner;

public class Wordgame
{
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        System.out.println("Enter a name");
        String name = console.nextLine();
        System.out.println("Enter an age");
        int age = Integer.parseInt(console.nextLine());
        System.out.println("Enter a city");
        String city = console.nextLine();
        System.out.println("Enter a University");
        String Uni = console.nextLine();
        System.out.println("Enter a Major");
        String Major = console.nextLine();
        System.out.println("Enter an animal");
        String animal = console.nextLine();
        System.out.println("Enter a Pet name");
        String Pet = console.nextLine();

        System.out.printf("Once upon a time there lived %s ,they were %d years old. They lived in %s with their pet %s. %n Today %s was nervous. Today was the day that the moved to %s to study %s. Their pet %s named %s %n was sad but hopeful for their friends return. Fin",name,age,city,animal,name,Uni,Major,animal,Pet);
    }
}
