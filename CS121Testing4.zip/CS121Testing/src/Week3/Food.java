package Week3;

import java.util.Scanner;

public class Food {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        System.out.println("is anyone Vegetarian?");
        String Vegitarian = console.nextLine();
        System.out.println("is anyone Vegan?");
        String Vegan = console.nextLine();
        System.out.println("is anyone gluten free?");
        String gluten = console.nextLine();
        System.out.println("here are your choices.");
        if (Vegan.equals("no")) {
            System.out.println("Mainstreet pizza\n");
        }
        if (Vegan.equals("no") && gluten.equals("no")) {
            System.out.println("Mama's fine itallian\n");
        }
        if (Vegan.equals("no") && gluten.equals("no") && Vegitarian.equals("no")) {
            System.out.println("Joes burger\n");
        }
        if (Vegan.equals("yes") && gluten.equals("yes") && Vegitarian.equals("yes")) {
            System.out.println("Chefs Kitchen");
            System.out.println("Corner cafe");
        }
    }
}
