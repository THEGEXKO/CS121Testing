package Week3;

import javax.swing.*;

public class Login {
    public static void main(String[] args) {
        String Uname = JOptionPane.showInputDialog(null, "Enter username");
        String promptInfo = "";
        String PassInfo = "";
        switch (Uname) {
            case "Eli":
                promptInfo = "username good.";
                String password = JOptionPane.showInputDialog(null, "Enter The password");
                switch (password) {
                    case "Pass":
                        PassInfo = "Password correct, Welcome to CS121";
                        break;
                    default:
                        PassInfo = "Password is incorrect. bye.";
                        break;
                }
            default:
                promptInfo = "Wrong Username.";
                break;

        }
        JOptionPane.showMessageDialog(null, PassInfo);
        JOptionPane.showMessageDialog(null, promptInfo);
    }
}