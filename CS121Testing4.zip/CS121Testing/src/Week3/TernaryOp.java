package Week3;

public class TernaryOp {
    public static void main(String[] args) {
        boolean isSunny, isWarm;
        isSunny = true;
        isWarm = false;


        if(isSunny && isWarm) {
            System.out.println("Lets go for ice cream");
        }else{
            System.out.println("Lets not get ice cream");
        }
        if (isSunny || isWarm){
            System.out.println("Its either sunny or warm. Lets go for a walk.");
        }

        int num = 8;
        String results = (num % 2 == 0)? "Even" : "Odd";
        System.out.println("The number is "+ results);
        int x = 5;
        int y = 6;
        int z = 7;

        if (x < y && x < z) {
            System.out.println("x is the smallest number");
        } if (z > x && z > y) {
            System.out.println("z is the largest number");
        } if (y > x && y < z) {
            System.out.println("y is the middle number");
        }
    }
}
