package Week4;

import javax.swing.*;

public class Hoteloccupancy {
    public static void main(String[] args) {
        int totalroom = 0;
        int floor = Integer.parseInt(JOptionPane.showInputDialog("How many floors does the hotel have?"));
        for (int i = 1; i <= floor; i++) {
            int room = Integer.parseInt(JOptionPane.showInputDialog("How many rooms does this floor have?"));
            int occupied = Integer.parseInt(JOptionPane.showInputDialog("How many occupied rooms on this floor have?"));
            for (int a = 1; a <= floor; a++){
                room =+ totalroom;
            }
        }System.out.println(totalroom);
   }
}