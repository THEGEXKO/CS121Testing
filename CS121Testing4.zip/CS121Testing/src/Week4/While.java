package Week4;

public class While {
    public static void main(String[] args) {
        int i = 0;
        while(i <= 5){
            System.out.println("This is what i is "+i);
            i++;
        }
        do{
            System.out.println("This is what i is "+i);
            i++;
        }while(i <=5);
    }
}
