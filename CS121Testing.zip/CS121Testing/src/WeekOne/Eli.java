package WeekOne;

public class Eli {
    public static void main(String[] args) {
        int age;
        double gpa;
        char letterGrade;
        boolean csMajor;
        String name;
        String favoriteColor;
        String HomeTown;
        String FavoriteFood;

        //intialize variables
        name = "ELI";
        gpa = 3.6;
        letterGrade = 'A';
        csMajor = true;
        age = 19;
        HomeTown = "Avon";
        favoriteColor = "Purple";
        FavoriteFood = "fried rice";

        System.out.printf( "\n Hello my name is \n %s", name);
        System.out.printf( "\n I come from \n %s",HomeTown);
        System.out.printf( "\n My GPA is \n %s ",gpa);
        System.out.printf("\n My letter grade is \n %s",letterGrade);
    }
}

